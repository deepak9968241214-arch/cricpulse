# CricPulse — Deploy Guide

## How it works
- `public/index.html` — your website (frontend, no API keys inside)
- `api/scores.js`     — serverless function that holds your API key securely
- Users hit `/api/scores` → server fetches from CricAPI → returns clean data

---

## Step 1 — Get a free CricAPI key (2 minutes)
1. Go to https://cricketdata.org
2. Click "Sign Up Free"
3. Copy your API key

---

## Step 2 — Deploy to Vercel (free)
1. Go to https://vercel.com and sign up with GitHub
2. Click "Add New Project"
3. Upload this folder OR push it to a GitHub repo and import it
4. During setup, click **"Environment Variables"** and add:
   - Name:  `CRICAPI_KEY`
   - Value: (paste your key from Step 1)
5. Click Deploy

That's it. Your site will be live at `yourproject.vercel.app`

---

## Free tier limits
- CricAPI free: 100 calls/day
- Site auto-refreshes every 90 seconds = ~96 calls/day ✅
- Vercel free: 100GB bandwidth, unlimited deploys ✅

---

## To update your site
Just edit `public/index.html` and redeploy (or push to GitHub for auto-deploy).
